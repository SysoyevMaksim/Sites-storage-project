// Получаем кнопку и добавляем обработчик события "click"
const randomPieButton = document.querySelector('#randomPieButton');
randomPieButton.addEventListener('click', () => {
  // Создаем массив с названиями пирогов
  const pies = ['Яблочный пирог', 'Тыквенный пирог', 'Сырный пирог'];
  // Выбираем случайный пирог
  const randomPieIndex = Math.floor(Math.random() * pies.length);
  const randomPieName = pies[randomPieIndex];
  // Создаем элемент всплывающего окна и добавляем его на страницу
  const popup = document.createElement('div');
  popup.classList.add('popup');
  popup.innerHTML = `<p>Случайный пирог: ${randomPieName}</p><button id="closePopupButton">Закрыть</button>`;
  document.body.appendChild(popup);
  // Добавляем обработчик события "click" для кнопки "Закрыть"
  const closePopupButton = popup.querySelector('#closePopupButton');
  closePopupButton.addEventListener('click', () => {
    popup.remove();
  });
});